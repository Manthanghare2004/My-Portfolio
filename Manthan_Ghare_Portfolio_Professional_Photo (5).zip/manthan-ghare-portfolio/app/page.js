import Link from "next/link";
import ProfilePhoto from "../components/ProfilePhoto";
import Reveal from "../components/Reveal";
import styles from "./home.module.css";

export default function Home() {
  return (
    <>
      <section className={`container ${styles.hero}`}>
        <div className={styles.copy}>
          <p className="eyebrow">Hello, welcome to my portfolio</p>
          <h1>Hi, I’m <span>Manthan Ghare.</span></h1>
          <h2>Student · Technology Enthusiast · Learner</h2>
          <p className="lead">I’m building my skills, exploring technology, and turning ideas into practical projects. This portfolio is a place to share my journey and the work I’m proud of.</p>
          <div className={styles.actions}>
            <Link href="/projects" className="btn btn-primary">Explore my work <span>↗</span></Link>
            <Link href="/contact" className="btn btn-secondary">Get in touch</Link>
          </div>
          <div className={styles.availability}><span /> Open to learning and opportunities</div>
        </div>
        <div className={styles.visual}><ProfilePhoto /><div className={styles.orbit}>MG</div></div>
      </section>
      <section className="container section">
        <Reveal>
          <div className={styles.introCard}>
            <div><p className="eyebrow">A little about me</p><h2 className="section-title">Curious mind. Practical mindset.</h2></div>
            <p className="lead">I enjoy learning how technology works and using that knowledge to create useful digital experiences. Visit the About page to learn more about my interests and skills.</p>
            <Link href="/about" className={styles.textLink}>More about me →</Link>
          </div>
        </Reveal>
      </section>
    </>
  );
}
