import Reveal from "../../components/Reveal";
import styles from "./about.module.css";

const skills = ["Communication", "Problem solving", "Teamwork", "HTML & CSS", "JavaScript", "React", "Next.js", "Git & GitHub"];

export default function About() {
  return (
    <section className="container section">
      <Reveal><p className="eyebrow">Get to know me</p><h1 className="section-title">About me<span className={styles.dot}>.</span></h1>
        <p className="lead">I’m Manthan Ghare. I’m a student who enjoys exploring technology, learning new tools, and improving through hands-on practice. I believe that consistent learning and building projects are important steps toward becoming a better developer.</p>
      </Reveal>
      <div className={`${styles.columns} grid`}>
        <Reveal><article className="card"><p className="eyebrow">My journey</p><h2>Learning by doing</h2><p className="lead">I like understanding a concept and then applying it in a small project. I’m continuing to develop my technical and professional skills through coursework and independent practice.</p></article></Reveal>
        <Reveal delay={0.12}><article className="card"><p className="eyebrow">My focus</p><h2>Build useful things</h2><p className="lead">My current focus is strengthening my foundations in web development, writing cleaner code, and creating responsive websites that are easy to use.</p></article></Reveal>
      </div>
      <Reveal><div className={styles.skills}><p className="eyebrow">Skills & interests</p><h2 className="section-title">Things I’m working with</h2><div>{skills.map((skill) => <span className="tag" key={skill}>{skill}</span>)}</div><p className={styles.note}>Edit this list to match your actual skills before submitting.</p></div></Reveal>
    </section>
  );
}
