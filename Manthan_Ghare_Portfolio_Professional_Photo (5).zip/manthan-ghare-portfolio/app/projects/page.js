"use client";

import { motion } from "motion/react";
import Reveal from "../../components/Reveal";
import styles from "./projects.module.css";

const projects = [
  { number: "01", title: "Project One", type: "Web Development", description: "Add the name and a short explanation of one project you have completed. Mention the problem it solves and your contribution.", tech: ["React", "CSS", "JavaScript"], link: "" },
  { number: "02", title: "Project Two", type: "Academic Project", description: "Describe another academic or personal project. Explain the main features and what you learned while building it.", tech: ["Next.js", "Motion"], link: "" },
  { number: "03", title: "Project Three", type: "Mini Project", description: "Add a third project, lab assignment, or useful experiment. Include a repository or live demo link when available.", tech: ["HTML", "CSS", "JavaScript"], link: "" },
];

export default function Projects() {
  return (
    <section className="container section">
      <Reveal><p className="eyebrow">Selected work</p><h1 className="section-title">My projects<span className={styles.dot}>.</span></h1><p className="lead">A few examples of what I’ve been learning and building. Replace these sample entries with your real projects.</p></Reveal>
      <div className={styles.projectGrid}>
        {projects.map((project, index) => (
          <motion.article key={project.number} className="card" initial={{ opacity: 0, y: 25 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: .5, delay: index * .12 }} whileHover={{ y: -7 }}>
            <div className={styles.topline}><span>{project.number}</span><span>{project.type}</span></div>
            <div className={styles.art}><span>MG</span><i>✳</i></div>
            <h2>{project.title}</h2><p className="lead">{project.description}</p>
            <div className={styles.tags}>{project.tech.map((t) => <span className="tag" key={t}>{t}</span>)}</div>
            <span className={styles.placeholder}>Add your GitHub / live demo link</span>
          </motion.article>
        ))}
      </div>
    </section>
  );
}
