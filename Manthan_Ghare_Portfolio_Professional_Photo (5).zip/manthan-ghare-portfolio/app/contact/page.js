import Reveal from "../../components/Reveal";
import styles from "./contact.module.css";

export default function Contact() {
  return (
    <section className="container section">
      <Reveal><p className="eyebrow">Let’s connect</p><h1 className="section-title">Contact me<span className={styles.dot}>.</span></h1><p className="lead">Have a question, an opportunity, or want to talk about a project? You can reach me through the details below.</p></Reveal>
      <Reveal delay={0.12}>
        <div className={styles.contactCard}>
          <div><span className="eyebrow">Email</span><h2>your-email@example.com</h2><p className="lead">Replace this with your active email address.</p><a className="btn btn-primary" href="mailto:your-email@example.com">Send an email ↗</a></div>
          <div className={styles.socials}>
            <a href="https://github.com/" target="_blank" rel="noreferrer">GitHub <span>↗</span></a>
            <a href="https://www.linkedin.com/" target="_blank" rel="noreferrer">LinkedIn <span>↗</span></a>
          </div>
        </div>
      </Reveal>
    </section>
  );
}
