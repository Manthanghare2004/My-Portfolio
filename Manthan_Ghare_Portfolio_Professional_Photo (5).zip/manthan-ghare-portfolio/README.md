# Manthan Ghare — Portfolio

A four-page responsive portfolio made with Next.js App Router, React, CSS Modules/global CSS, and Motion.

## Run on your Windows desktop

1. Install Node.js (LTS) from https://nodejs.org if it is not already installed.
2. Extract this ZIP file.
3. Open the extracted `manthan-ghare-portfolio` folder.
4. In File Explorer, click the address bar, type `cmd`, and press Enter.
5. Run:

   ```bash
   npm install
   npm run dev
   ```

6. Open the local address shown in the terminal (usually http://localhost:3000).
7. Keep the terminal open while viewing the site. Press `Ctrl + C` to stop it.

## Personalise before submission

- Your supplied photograph is already saved as `public/profile.jpg` and connected to the Home page.
- Update the email, education, skills, project names/descriptions, GitHub and LinkedIn links in the page files.
- Add your actual project screenshots to `public/` and update the project cards if available.

## Check the production build

```bash
npm run build
```

If it succeeds, the project compiles successfully.

## Pages

- `/` Home
- `/about` About
- `/projects` Projects
- `/contact` Contact

The portfolio uses Motion for page transitions, scroll reveals, and hover/tap effects. Layouts adapt to mobile, tablet, and desktop widths.
