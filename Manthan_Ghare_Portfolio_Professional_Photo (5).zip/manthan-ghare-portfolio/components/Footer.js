export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-inner">
        <span>© {new Date().getFullYear()} Manthan Ghare</span>
        <span>Designed and built with Next.js</span>
      </div>
    </footer>
  );
}
