"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import styles from "./Navbar.module.css";

const links = [
  ["/", "Home"], ["/about", "About"], ["/projects", "Projects"], ["/contact", "Contact"],
];

export default function Navbar() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  return (
    <header className={styles.header}>
      <nav className={`container ${styles.nav}`}>
        <Link href="/" className={styles.logo} onClick={() => setOpen(false)}>
          MG<span>.</span>
        </Link>
        <button className={styles.menuButton} onClick={() => setOpen(!open)} aria-label="Toggle navigation" aria-expanded={open}>
          {open ? "✕" : "☰"}
        </button>
        <div className={`${styles.links} ${open ? styles.open : ""}`}>
          {links.map(([href, label]) => (
            <Link key={href} href={href} onClick={() => setOpen(false)} className={pathname === href ? styles.active : ""}>
              {label}
            </Link>
          ))}
        </div>
      </nav>
    </header>
  );
}
