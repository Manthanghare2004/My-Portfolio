"use client";

import { motion } from "motion/react";

export default function ProfilePhoto() {
  return (
    <motion.div className="photo-frame" whileHover={{ rotate: 1.5, scale: 1.025 }} transition={{ duration: 0.25 }}>
      <img src="/profile.jpg" alt="Manthan Ghare" />
      
    </motion.div>
  );
}
